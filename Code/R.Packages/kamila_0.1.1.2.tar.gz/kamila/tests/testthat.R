library(testthat)
library(kamila)

test_check("kamila")
