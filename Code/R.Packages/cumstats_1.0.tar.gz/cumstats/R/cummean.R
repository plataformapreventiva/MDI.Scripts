cummean <-
function(x) cumsum(as.numeric(x))/seq_along(x)
