cumhmean <-
function(x) 1/(cummean(1/x))
