cumgmean <-
function(x) exp(cummean(log(x)))
